-- Run against outputs/expenses.db (created by src/analysis.py)
-- Example:  sqlite3 outputs/expenses.db < sql/queries.sql

-- 1. Total spend per category
SELECT category, SUM(amount) AS total_spent, COUNT(*) AS transactions
FROM expenses
GROUP BY category
ORDER BY total_spent DESC;

-- 2. Share of spend per category (%)
SELECT category,
       ROUND(100.0 * SUM(amount) / (SELECT SUM(amount) FROM expenses), 1) AS pct_of_total
FROM expenses
GROUP BY category
ORDER BY pct_of_total DESC;

-- 3. Top 5 biggest single expenses
SELECT date, category, description, amount
FROM expenses
ORDER BY amount DESC
LIMIT 5;

-- 4. Spend per payment method
SELECT payment_method, SUM(amount) AS total_spent
FROM expenses
GROUP BY payment_method
ORDER BY total_spent DESC;

-- 5. Days where spending was above the daily average
SELECT date, SUM(amount) AS day_total
FROM expenses
GROUP BY date
HAVING SUM(amount) > (SELECT SUM(amount) / COUNT(DISTINCT date) FROM expenses)
ORDER BY day_total DESC;

-- 6. Average transaction size by category
SELECT category, ROUND(AVG(amount), 1) AS avg_transaction
FROM expenses
GROUP BY category
ORDER BY avg_transaction DESC;
