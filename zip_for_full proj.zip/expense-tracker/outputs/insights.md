# Expense Insights
Source: `sample_expenses.csv`

## Data cleaning log
- rows loaded: 67
- invalid rows dropped: 0
- missing payment method filled: 1
- duplicates removed: 2
- rows after cleaning: 65

## Key numbers
- Period: 2026-10-01 to 2026-10-31 (31 days, 65 transactions)
- Total spent: INR 13,007
- Average per day: INR 420
- Biggest category: Food (INR 5,262, 40% of spend)
- Top 3 categories make up 82% of all spending
- Weekend vs weekday: INR 496 vs INR 388 per day (+28%)
- Most-used payment method: UPI (56% of spend)

## Top 5 single expenses
- 2026-10-10 | Shopping | Clothes | INR 1,499
- 2026-10-21 | Shopping | Clothes | INR 1,258
- 2026-10-20 | Shopping | Clothes | INR 780
- 2026-10-22 | Shopping | Clothes | INR 550
- 2026-10-10 | Bills | Internet share | INR 400

## Highest-spend days
- 2026-10-10: INR 1,972
- 2026-10-21: INR 1,373
- 2026-10-20: INR 1,313

## Takeaways
1. Food is the main driver of spending, so it is the first place to look when trying to save.
2. Spending on weekends is 28% higher per day than on weekdays.
3. Three categories account for 82% of the total, so tracking just those gives most of the picture.