"""Generate a DUMMY month of expenses so the project runs out of the box.

Replace data/expenses.csv with your own real data (same columns) to get
insights about your own spending.
"""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(42)
START = date(2026, 10, 1)
DAYS = 31

# category -> (list of (description, min, max), chance per day, payment methods)
SPEND = {
    "Food":          ([("Canteen lunch", 60, 120), ("Tea & snacks", 20, 60), ("Dinner with friends", 150, 400), ("Online food order", 180, 450)], 0.9, ["UPI", "Cash"]),
    "Transport":     ([("Auto/Cab", 40, 150), ("Metro/Bus", 10, 40)], 0.55, ["UPI", "Cash"]),
    "Education":     ([("Stationery", 30, 150), ("Online course", 300, 600), ("Printouts", 20, 60)], 0.12, ["UPI"]),
    "Entertainment": ([("Game top-up", 80, 300), ("Movie", 150, 350), ("Subscription", 99, 199)], 0.18, ["UPI", "Card"]),
    "Shopping":      ([("Clothes", 400, 1500), ("Accessories", 100, 500)], 0.07, ["UPI", "Card"]),
    "Personal Care": ([("Haircut", 100, 250), ("Toiletries", 80, 300)], 0.06, ["Cash", "UPI"]),
}

rows = []
for i in range(DAYS):
    d = START + timedelta(days=i)
    weekend = d.weekday() >= 5
    for cat, (items, p, methods) in SPEND.items():
        prob = p * (1.35 if weekend and cat in ("Food", "Entertainment", "Shopping") else 1)
        if random.random() < min(prob, 0.98):
            desc, lo, hi = random.choice(items)
            rows.append([d.isoformat(), cat, desc, random.randint(lo, hi), random.choice(methods)])

# Monthly fixed costs
rows.append([date(2026, 10, 5).isoformat(), "Bills", "Mobile recharge", 299, "UPI"])
rows.append([date(2026, 10, 10).isoformat(), "Bills", "Internet share", 400, "UPI"])

# A few deliberately messy rows so the cleaning step has real work to do
rows.append(rows[3][:])                                   # duplicate row
rows.append(rows[10][:])                                  # duplicate row
rows.append(["2026-10-14", "food", "Snacks", 45, "cash"]) # inconsistent case
rows.append(["2026-10-21", "Transport", "Auto", 70, ""])  # missing payment method

rows.sort(key=lambda r: r[0])
out = Path(__file__).resolve().parent.parent / "data" / "sample_expenses.csv"
with open(out, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["date", "category", "description", "amount", "payment_method"])
    w.writerows(rows)
print(f"Wrote {len(rows)} rows to {out}")
