"""Personal Expense Tracker - cleaning, analysis, charts and insights.

Usage:
    python src/analysis.py                      # uses data/expenses.csv if present, else sample data
    python src/analysis.py path/to/your.csv     # use your own file
"""
import sqlite3
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # no display needed
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "outputs"
CHARTS = OUT / "charts"
CHARTS.mkdir(parents=True, exist_ok=True)


# ---------- 1. Load ----------
def pick_file() -> Path:
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    mine = ROOT / "data" / "expenses.csv"
    return mine if mine.exists() else ROOT / "data" / "sample_expenses.csv"


# ---------- 2. Clean ----------
def clean(df: pd.DataFrame):
    log = {"rows_loaded": len(df)}
    df = df.copy()
    df.columns = df.columns.str.strip().str.lower()

    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    log["invalid_rows_dropped"] = int(df[["date", "amount"]].isna().any(axis=1).sum())
    df = df.dropna(subset=["date", "amount"])

    df["category"] = df["category"].astype(str).str.strip().str.title()
    df["description"] = df["description"].astype(str).str.strip()
    pm = df["payment_method"].fillna("").astype(str).str.strip().str.lower()
    log["missing_payment_method_filled"] = int((pm == "").sum())
    names = {"upi": "UPI", "cash": "Cash", "card": "Card", "": "Unknown"}
    df["payment_method"] = pm.map(lambda x: names.get(x, x.title()))

    before = len(df)
    df = df.drop_duplicates()
    log["duplicates_removed"] = before - len(df)

    df = df.sort_values("date").reset_index(drop=True)
    df["weekday"] = df["date"].dt.day_name()
    df["is_weekend"] = df["date"].dt.weekday >= 5
    df["week"] = df["date"].dt.to_period("W").apply(lambda p: p.start_time.date())
    log["rows_after_cleaning"] = len(df)
    return df, log


# ---------- 3. Analyse ----------
def analyse(df: pd.DataFrame) -> dict:
    days = pd.date_range(df["date"].min(), df["date"].max())
    daily = df.groupby("date")["amount"].sum().reindex(days, fill_value=0)

    by_cat = df.groupby("category")["amount"].sum().sort_values(ascending=False)
    by_pay = df.groupby("payment_method")["amount"].sum().sort_values(ascending=False)
    weekly = df.groupby("week")["amount"].sum()

    weekend_avg = daily[daily.index.weekday >= 5].mean()
    weekday_avg = daily[daily.index.weekday < 5].mean()

    return {
        "total": df["amount"].sum(),
        "avg_daily": daily.mean(),
        "n_days": len(days),
        "n_txn": len(df),
        "by_cat": by_cat,
        "by_pay": by_pay,
        "weekly": weekly,
        "daily": daily,
        "weekend_avg": weekend_avg,
        "weekday_avg": weekday_avg,
        "top_expenses": df.nlargest(5, "amount")[["date", "category", "description", "amount"]],
        "top_days": daily.nlargest(3),
    }


# ---------- 4. Charts ----------
def charts(r: dict):
    plt.rcParams.update({"figure.dpi": 130, "axes.spines.top": False, "axes.spines.right": False})
    blue = "#1F3A5F"

    fig, ax = plt.subplots(figsize=(7, 4))
    cat = r["by_cat"].sort_values()
    ax.barh(cat.index, cat.values, color=blue)
    ax.set_title("Spending by category"); ax.set_xlabel("Amount (INR)")
    for i, v in enumerate(cat.values):
        ax.text(v, i, f" {v:,.0f}", va="center", fontsize=8)
    fig.tight_layout(); fig.savefig(CHARTS / "spend_by_category.png"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot([str(w) for w in r["weekly"].index], r["weekly"].values, marker="o", color=blue)
    ax.set_title("Weekly spending trend"); ax.set_ylabel("Amount (INR)"); ax.set_xlabel("Week starting")
    ax.tick_params(axis="x", rotation=30)
    fig.tight_layout(); fig.savefig(CHARTS / "weekly_trend.png"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.bar(r["daily"].index, r["daily"].values, color=blue, width=0.8)
    ax.axhline(r["avg_daily"], color="crimson", linestyle="--", label=f"Daily average: {r['avg_daily']:,.0f}")
    ax.set_title("Daily spending"); ax.set_ylabel("Amount (INR)"); ax.legend()
    fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(CHARTS / "daily_spend.png"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4))
    vals = [r["weekday_avg"], r["weekend_avg"]]
    ax.bar(["Weekday", "Weekend"], vals, color=[blue, "#C9822B"])
    ax.set_title("Average daily spend: weekday vs weekend"); ax.set_ylabel("Amount (INR)")
    for i, v in enumerate(vals):
        ax.text(i, v, f"{v:,.0f}", ha="center", va="bottom")
    fig.tight_layout(); fig.savefig(CHARTS / "weekday_vs_weekend.png"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.pie(r["by_pay"].values, labels=r["by_pay"].index, autopct="%1.0f%%", startangle=90,
           colors=[blue, "#C9822B", "#6B8E9E", "#B0B0B0"][: len(r["by_pay"])])
    ax.set_title("Payment methods (share of spend)")
    fig.tight_layout(); fig.savefig(CHARTS / "payment_methods.png"); plt.close(fig)


# ---------- 5. Insights report ----------
def report(df, r, log, source) -> str:
    top_cat = r["by_cat"].index[0]
    top_share = r["by_cat"].iloc[0] / r["total"] * 100
    diff = (r["weekend_avg"] / r["weekday_avg"] - 1) * 100
    top3 = r["by_cat"].head(3).sum() / r["total"] * 100
    lines = [
        "# Expense Insights",
        f"Source: `{source}`",
        "",
        "## Data cleaning log",
        *[f"- {k.replace('_', ' ')}: {v}" for k, v in log.items()],
        "",
        "## Key numbers",
        f"- Period: {df['date'].min().date()} to {df['date'].max().date()} ({r['n_days']} days, {r['n_txn']} transactions)",
        f"- Total spent: INR {r['total']:,.0f}",
        f"- Average per day: INR {r['avg_daily']:,.0f}",
        f"- Biggest category: {top_cat} (INR {r['by_cat'].iloc[0]:,.0f}, {top_share:.0f}% of spend)",
        f"- Top 3 categories make up {top3:.0f}% of all spending",
        f"- Weekend vs weekday: INR {r['weekend_avg']:,.0f} vs INR {r['weekday_avg']:,.0f} per day ({diff:+.0f}%)",
        f"- Most-used payment method: {r['by_pay'].index[0]} ({r['by_pay'].iloc[0] / r['total'] * 100:.0f}% of spend)",
        "",
        "## Top 5 single expenses",
        *[f"- {row.date.date()} | {row.category} | {row.description} | INR {row.amount:,.0f}" for row in r["top_expenses"].itertuples()],
        "",
        "## Highest-spend days",
        *[f"- {d.date()}: INR {v:,.0f}" for d, v in r["top_days"].items()],
        "",
        "## Takeaways",
        f"1. {top_cat} is the main driver of spending, so it is the first place to look when trying to save.",
        f"2. Spending on weekends is {abs(diff):.0f}% {'higher' if diff > 0 else 'lower'} per day than on weekdays.",
        f"3. Three categories account for {top3:.0f}% of the total, so tracking just those gives most of the picture.",
    ]
    return "\n".join(lines)


# ---------- 6. SQLite export (for sql/queries.sql) ----------
def to_sqlite(df: pd.DataFrame):
    db = OUT / "expenses.db"
    out = df[["date", "category", "description", "amount", "payment_method"]].copy()
    out["date"] = out["date"].dt.strftime("%Y-%m-%d")
    with sqlite3.connect(db) as con:
        out.to_sql("expenses", con, if_exists="replace", index=False)


def main():
    src = pick_file()
    raw = pd.read_csv(src)
    df, log = clean(raw)
    r = analyse(df)
    charts(r)
    text = report(df, r, log, src.name)
    (OUT / "insights.md").write_text(text, encoding="utf-8")
    df.to_csv(OUT / "cleaned_expenses.csv", index=False)
    to_sqlite(df)
    print(text)
    print(f"\nCharts saved in {CHARTS}")


if __name__ == "__main__":
    main()
