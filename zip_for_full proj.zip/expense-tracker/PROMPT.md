# Project Prompt

This file contains the prompt used to plan and build this project with an AI assistant. You can paste it into any AI assistant (Claude, ChatGPT, etc.) to rebuild the project, or edit it to extend the project.

> Tip: Always read and run the code yourself. Make sure you can explain every step, because that is what interviewers will ask.

---

## Prompt

```
Act as a friendly senior data analyst mentoring a first-year B.Tech student
who knows basic Excel, basic SQL and Python (pandas, matplotlib).

GOAL
Help me build a beginner-friendly portfolio project called
"Personal Expense Tracker with Insights" that I can upload to GitHub and
mention on my CV for a data analyst internship.

DATA
- Use a CSV with these columns: date, category, description, amount, payment_method.
- Generate a DUMMY dataset for one month (about 60-100 rows, amounts in INR).
- Categories: Food, Transport, Education, Entertainment, Shopping, Bills, Personal Care.
- Include a few deliberately messy rows (duplicates, inconsistent category
  capitalisation, a missing payment method) so the cleaning step is meaningful.
- Make clear in the README that the data is dummy and can be replaced with real data.

ANALYSIS (Python: pandas + matplotlib)
1. Load and clean the data: standardise text, parse dates, remove duplicates,
   fill missing values, drop invalid rows, and print a short cleaning log.
2. Answer these questions:
   - Which categories take the biggest share of spending?
   - How does spending change week by week?
   - Do I spend more on weekends than on weekdays?
   - Which payment methods do I use most?
   - What are the top 5 single expenses and top 3 highest-spend days?
3. Save 5 clean, labelled charts as PNG files (category bar chart, weekly
   trend, daily spend with average line, weekday vs weekend, payment methods).
4. Auto-generate an insights.md report with key numbers and 3 plain-language takeaways.

SQL
- Export the cleaned data to a SQLite database.
- Write 6 beginner-friendly SQL queries (GROUP BY, ORDER BY, HAVING,
  a subquery) with a comment above each explaining what it answers.

PROJECT STRUCTURE AND DELIVERABLES
- A GitHub-ready folder: data/, src/, sql/, outputs/charts/.
- README.md with: overview, questions answered, sample results, embedded
  charts, project structure, setup steps, how to use my own data, skills
  demonstrated, and next-step ideas.
- requirements.txt, .gitignore (ignore my personal data file), MIT LICENSE.

CODING RULES
- Keep the code simple, well commented and readable for a beginner.
- Use functions, no unnecessary libraries, and make it run with one command:
  python src/analysis.py
- After the code, explain each step in simple words so I can describe the
  project confidently in an interview, and suggest 3 interview questions I
  might be asked about it with good sample answers.
```

---

## How to use it

1. Paste the prompt into your AI assistant.
2. Run the code it gives you and check that the outputs match what the README says.
3. Replace the dummy data with your own expenses for a month.
4. Update the README numbers and charts from your real results.
5. Commit and push to GitHub.

## Optional follow-up prompts

- "Add a monthly budget per category and flag the categories that go over budget."
- "Extend this to 3 months of data and compare month-on-month changes."
- "Explain `analysis.py` line by line as if I'm preparing for an interview."
- "Help me turn `cleaned_expenses.csv` into an Excel dashboard with pivot tables."
